const nodemailer = require("nodemailer");

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST) return null; // dev mode, no SMTP configured

  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || "587", 10),
    secure: process.env.SMTP_PORT === "465",
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
  return transporter;
}

async function sendOtpEmail(toEmail, code) {
  const t = getTransporter();

  if (!t) {
    // Local dev fallback: no SMTP configured, so just log it.
    console.log(`\n[DEV] Verification code for ${toEmail}: ${code}\n`);
    return { delivered: false, dev: true };
  }

  await t.sendMail({
    from: process.env.SMTP_FROM || "no-reply@yourapp.com",
    to: toEmail,
    subject: "Your verification code",
    text: `Your verification code is ${code}. It expires in ${process.env.OTP_EXPIRY_MINUTES || 5} minutes.`,
    html: `<p>Your verification code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:4px">${code}</p><p>It expires in ${process.env.OTP_EXPIRY_MINUTES || 5} minutes.</p>`,
  });

  return { delivered: true, dev: false };
}

module.exports = { sendOtpEmail };
