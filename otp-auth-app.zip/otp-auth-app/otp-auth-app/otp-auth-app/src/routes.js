const express = require("express");
const bcrypt = require("bcryptjs");
const rateLimit = require("express-rate-limit");

const store = require("./store");
const otp = require("./otp");
const { sendOtpEmail } = require("./mailer");
const { signToken, requireAuth } = require("./auth");

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Slow down brute-force attempts against the OTP verify endpoint specifically.
const verifyLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many attempts. Please wait a few minutes and try again." },
});

function badRequest(res, message) {
  return res.status(400).json({ error: message });
}

// --- Signup: create the account, then immediately require email verification ---
router.post("/signup", async (req, res) => {
  const { name, email, password } = req.body || {};

  if (!name || !email || !password) {
    return badRequest(res, "Name, email, and password are all required.");
  }
  if (!EMAIL_RE.test(email)) {
    return badRequest(res, "Please provide a valid email address.");
  }
  if (password.length < 8) {
    return badRequest(res, "Password must be at least 8 characters.");
  }
  if (store.getUserByEmail(email)) {
    return badRequest(res, "An account with that email already exists.");
  }

  const passwordHash = await bcrypt.hash(password, 10);
  store.createUser({ name, email, passwordHash });

  const issued = otp.issueOtp(email);
  if (!issued.ok) {
    return res.status(429).json({
      error: `Please wait ${issued.retryAfterSeconds}s before requesting another code.`,
    });
  }
  await sendOtpEmail(email, issued.code);

  res.status(201).json({ message: "Account created. Check your email for a verification code.", email });
});

// --- Login step 1: verify credentials, then issue a fresh OTP as the 2nd factor ---
router.post("/login", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return badRequest(res, "Email and password are required.");

  const user = store.getUserByEmail(email);
  // Same generic error whether the email doesn't exist or the password is wrong,
  // so an attacker can't use this endpoint to enumerate registered emails.
  const genericError = { error: "Incorrect email or password." };

  if (!user) return res.status(401).json(genericError);

  const passwordOk = await bcrypt.compare(password, user.passwordHash);
  if (!passwordOk) return res.status(401).json(genericError);

  const issued = otp.issueOtp(email);
  if (!issued.ok) {
    return res.status(429).json({
      error: `Please wait ${issued.retryAfterSeconds}s before requesting another code.`,
    });
  }
  await sendOtpEmail(email, issued.code);

  res.json({ message: "Password verified. Enter the code sent to your email.", email });
});

// --- Step 2 (both signup and login funnel here): verify the 6-digit code ---
router.post("/verify-otp", verifyLimiter, async (req, res) => {
  const { email, code } = req.body || {};
  if (!email || !code) return badRequest(res, "Email and code are required.");

  const user = store.getUserByEmail(email);
  if (!user) return badRequest(res, "No account found for that email.");

  const result = otp.verifyOtp(email, code);

  if (!result.ok) {
    const messages = {
      no_active_code: "No active code for this email. Request a new one.",
      expired: "That code has expired. Request a new one.",
      too_many_attempts: "Too many incorrect attempts. Request a new code.",
      incorrect: `Incorrect code. ${result.attemptsLeft} attempt(s) left.`,
    };
    return res.status(400).json({ error: messages[result.reason] || "Verification failed." });
  }

  store.markUserVerified(email);
  const token = signToken(user);

  res.json({
    message: "Verified.",
    token,
    user: { id: user.id, name: user.name, email: user.email },
  });
});

// --- Resend, with the cooldown enforced inside issueOtp ---
router.post("/resend-otp", async (req, res) => {
  const { email } = req.body || {};
  if (!email) return badRequest(res, "Email is required.");
  if (!store.getUserByEmail(email)) return badRequest(res, "No account found for that email.");

  const issued = otp.issueOtp(email);
  if (!issued.ok) {
    return res.status(429).json({
      error: `Please wait ${issued.retryAfterSeconds}s before requesting another code.`,
    });
  }
  await sendOtpEmail(email, issued.code);
  res.json({ message: "A new code has been sent." });
});

// --- Example protected route ---
router.get("/me", requireAuth, (req, res) => {
  const user = store.getUserByEmail(req.user.email);
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json({ id: user.id, name: user.name, email: user.email, verified: user.verified });
});

module.exports = router;
