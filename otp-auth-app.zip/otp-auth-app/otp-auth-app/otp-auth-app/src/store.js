// In-memory store — swap these Maps for a real database (Postgres, Mongo, etc.)
// in production. Kept simple here so the auth flow itself is easy to read.

const users = new Map(); // email -> { id, name, email, passwordHash, verified }
const otps = new Map(); // email -> { code, expiresAt, attempts, lastSentAt }

let nextId = 1;

function createUser({ name, email, passwordHash }) {
  const user = { id: nextId++, name, email, passwordHash, verified: false };
  users.set(email, user);
  return user;
}

function getUserByEmail(email) {
  return users.get(email) || null;
}

function markUserVerified(email) {
  const user = users.get(email);
  if (user) user.verified = true;
}

function setOtp(email, record) {
  otps.set(email, record);
}

function getOtp(email) {
  return otps.get(email) || null;
}

function clearOtp(email) {
  otps.delete(email);
}

module.exports = {
  createUser,
  getUserByEmail,
  markUserVerified,
  setOtp,
  getOtp,
  clearOtp,
};
