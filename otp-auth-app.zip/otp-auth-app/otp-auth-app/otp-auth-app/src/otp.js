const crypto = require("crypto");
const store = require("./store");

const OTP_LENGTH = parseInt(process.env.OTP_LENGTH || "6", 10);
const OTP_EXPIRY_MINUTES = parseInt(process.env.OTP_EXPIRY_MINUTES || "5", 10);
const OTP_MAX_ATTEMPTS = parseInt(process.env.OTP_MAX_ATTEMPTS || "5", 10);
const RESEND_COOLDOWN_SECONDS = parseInt(
  process.env.OTP_RESEND_COOLDOWN_SECONDS || "30",
  10
);

// Cryptographically-random numeric code, e.g. "042917" for length 6.
function generateCode(length = OTP_LENGTH) {
  const max = 10 ** length;
  const num = crypto.randomInt(0, max);
  return String(num).padStart(length, "0");
}

// Store codes as a hash rather than plaintext, same idea as password hashing —
// if the store ever leaked, the codes themselves wouldn't be directly usable.
function hashCode(code) {
  return crypto.createHash("sha256").update(code).digest("hex");
}

function issueOtp(email) {
  const existing = store.getOtp(email);
  if (existing && existing.lastSentAt) {
    const secondsSinceLast = (Date.now() - existing.lastSentAt) / 1000;
    if (secondsSinceLast < RESEND_COOLDOWN_SECONDS) {
      return {
        ok: false,
        retryAfterSeconds: Math.ceil(RESEND_COOLDOWN_SECONDS - secondsSinceLast),
      };
    }
  }

  const code = generateCode();
  store.setOtp(email, {
    codeHash: hashCode(code),
    expiresAt: Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000,
    attempts: 0,
    lastSentAt: Date.now(),
  });

  return { ok: true, code };
}

function verifyOtp(email, submittedCode) {
  const record = store.getOtp(email);
  if (!record) return { ok: false, reason: "no_active_code" };

  if (Date.now() > record.expiresAt) {
    store.clearOtp(email);
    return { ok: false, reason: "expired" };
  }

  if (record.attempts >= OTP_MAX_ATTEMPTS) {
    store.clearOtp(email);
    return { ok: false, reason: "too_many_attempts" };
  }

  record.attempts += 1;

  const submittedHash = hashCode(String(submittedCode || "").trim());
  if (submittedHash !== record.codeHash) {
    return {
      ok: false,
      reason: "incorrect",
      attemptsLeft: OTP_MAX_ATTEMPTS - record.attempts,
    };
  }

  store.clearOtp(email);
  return { ok: true };
}

module.exports = { issueOtp, verifyOtp };
