# Vault — Email OTP Authentication Demo

Signup + login secured by a 6-digit email verification code, built with Node.js/Express.

## What's inside

- **Password auth**: bcrypt-hashed passwords, never stored or logged in plaintext.
- **6-digit OTP as 2nd factor**: sent after signup and after every login. Codes are
  hashed (SHA-256) before being stored, expire after 5 minutes, and are rate-limited
  (max attempts + resend cooldown).
- **JWT session**: issued only after the OTP is verified, used to protect `/api/me`.
- **In-memory store**: `src/store.js` uses plain JS `Map`s so you can read the whole
  auth flow without a database in the way. Swap it for Postgres/Mongo/etc. before
  shipping this for real — an in-memory store forgets everyone every time the
  server restarts.
- **Minimal frontend**: `public/` — signup → login → verify → success, no framework.

## Setup

```bash
cd otp-auth-app
npm install
cp .env.example .env
# edit .env: at minimum, set JWT_SECRET to a long random string
npm start
```

Open http://localhost:3000

### Sending real emails

Without SMTP configured, codes are printed to the server console (`[DEV] Verification code for you@example.com: 481203`) so you can test the whole flow with zero setup.

To send real emails, fill in the SMTP block in `.env`. Any SMTP provider works
(Gmail app password, SendGrid, Postmark, Mailgun, Amazon SES, etc.):

```
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your_sendgrid_api_key
SMTP_FROM="Vault <no-reply@yourapp.com>"
```

### Switching to SMS instead of email

The OTP logic in `src/otp.js` is transport-agnostic — it just returns a code.
To send it via SMS instead of email, add a `src/sms.js` following the same shape
as `src/mailer.js`, using a provider like Twilio:

```js
const twilio = require("twilio")(accountSid, authToken);
async function sendOtpSms(toPhone, code) {
  await twilio.messages.create({
    body: `Your verification code is ${code}`,
    from: process.env.TWILIO_FROM,
    to: toPhone,
  });
}
```

Then call `sendOtpSms` instead of (or alongside) `sendOtpEmail` in `src/routes.js`.

## API reference

| Method | Path              | Body                          | Notes                                   |
|--------|-------------------|--------------------------------|------------------------------------------|
| POST   | `/api/signup`      | `name, email, password`        | Creates account, sends OTP               |
| POST   | `/api/login`       | `email, password`               | Checks password, sends OTP               |
| POST   | `/api/verify-otp`  | `email, code`                   | Returns a JWT on success                 |
| POST   | `/api/resend-otp`  | `email`                         | Rate-limited (30s cooldown by default)   |
| GET    | `/api/me`          | — (`Authorization: Bearer <jwt>`) | Protected route example                |

## Security notes worth keeping as you extend this

- OTP codes are hashed before storage and compared as hashes — never stored or
  logged in plaintext outside of the dev-mode console fallback.
- The login endpoint returns the same error for "no such user" and "wrong
  password" so the API can't be used to check which emails are registered.
- OTP verification is rate-limited both per-code (max attempts before it's
  invalidated) and per-IP (via `express-rate-limit`) to slow down brute force.
- `JWT_SECRET` **must** be changed from the example value and kept out of
  version control before any real deployment.

## how to run 
npm start
