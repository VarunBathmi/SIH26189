const views = ["signup", "login", "verify", "success"];
let pendingEmail = null;
let sessionToken = null;

function showView(name) {
  views.forEach((v) => {
    document.getElementById(`view-${v}`).classList.toggle("active", v === name);
  });
  setMsg("");
}

function setMsg(text, type = "") {
  const el = document.getElementById("msg");
  el.textContent = text;
  el.className = "msg" + (type ? ` ${type}` : "");
}

async function api(path, body) {
  const res = await fetch(`/api${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

document.querySelectorAll("[data-goto]").forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    showView(link.dataset.goto);
  });
});

document.getElementById("form-signup").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  try {
    const data = await api("/signup", {
      name: form.get("name"),
      email: form.get("email"),
      password: form.get("password"),
    });
    pendingEmail = data.email;
    document.getElementById("verify-email").textContent = pendingEmail;
    showView("verify");
    setMsg("Code sent. Check your email (or the server console in dev mode).", "success");
  } catch (err) {
    setMsg(err.message, "error");
  }
});

document.getElementById("form-login").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  try {
    const data = await api("/login", {
      email: form.get("email"),
      password: form.get("password"),
    });
    pendingEmail = data.email;
    document.getElementById("verify-email").textContent = pendingEmail;
    showView("verify");
    setMsg("Code sent. Check your email (or the server console in dev mode).", "success");
  } catch (err) {
    setMsg(err.message, "error");
  }
});

document.getElementById("form-verify").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  try {
    const data = await api("/verify-otp", {
      email: pendingEmail,
      code: form.get("code"),
    });
    sessionToken = data.token;
    document.getElementById("success-email").textContent = data.user.email;
    showView("success");
  } catch (err) {
    setMsg(err.message, "error");
  }
});

document.getElementById("resend-link").addEventListener("click", async (e) => {
  e.preventDefault();
  try {
    await api("/resend-otp", { email: pendingEmail });
    setMsg("New code sent.", "success");
  } catch (err) {
    setMsg(err.message, "error");
  }
});

document.getElementById("logout-btn").addEventListener("click", () => {
  sessionToken = null;
  pendingEmail = null;
  document.getElementById("form-login").reset();
  document.getElementById("form-signup").reset();
  showView("login");
});
